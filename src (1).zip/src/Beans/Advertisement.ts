export class Advertisement{
crop_Id:number;
crop_Name:String;
crop_Qty:String;
docId:number;
docType:string;
docData:string;



constructor(crop_Id:number,crop_Name:string,crop_Qty:string,docId:number,docType:string,docData:string){
    this.crop_Id=crop_Id;
    this.crop_Name=crop_Name;
    this.crop_Qty=crop_Qty;
    this.docId = docId;
    this.docType = docType;
  //  this.docData=docData;
}
}