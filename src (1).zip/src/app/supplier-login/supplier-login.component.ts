import { Component, OnInit } from '@angular/core';
import { FarmerServiceService } from '../farmer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-supplier-login',
  templateUrl: './supplier-login.component.html',
  styleUrls: ['./supplier-login.component.css']
})
export class SupplierLoginComponent implements OnInit {

  farmerServ:FarmerServiceService;
  router:Router;
  constructor(farmerServ:FarmerServiceService,router:Router) {
    this.farmerServ=farmerServ;
    this.router=router;
   }

  ngOnInit() {
  }
  supplierLogin(data:any){
  this.farmerServ.loginSupplier(data.supplier_Email, data.supplier_Password).subscribe((res) =>{ 

    if (res === null)
      alert("please enter valid login details");

    else{
    //this.router.navigate(["/farmerHome",this.email]);
    this.router.navigateByUrl("supplierHome", data.supplier_Email);
    alert("Login Successfully " + data.supplier_Email);
    }
    }
    )
  }

}
