import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewProductRequirementComponent } from './view-product-requirement.component';

describe('ViewProductRequirementComponent', () => {
  let component: ViewProductRequirementComponent;
  let fixture: ComponentFixture<ViewProductRequirementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewProductRequirementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewProductRequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
