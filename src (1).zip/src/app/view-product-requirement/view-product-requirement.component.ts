import { Component, OnInit } from '@angular/core';
import { Crop } from 'src/Beans/Crop';
import { FarmerServiceService } from '../farmer-service.service';

@Component({
  selector: 'app-view-product-requirement',
  templateUrl: './view-product-requirement.component.html',
  styleUrls: ['./view-product-requirement.component.css']
})
export class ViewProductRequirementComponent implements OnInit {

  crops;
  farmerServ:FarmerServiceService;

  constructor(farmerServ:FarmerServiceService) { 
   this.farmerServ=farmerServ;
  }

  ngOnInit() {
    this.farmerServ.fetchProductRequirements().subscribe(data => this.crops = data);
  }

}
