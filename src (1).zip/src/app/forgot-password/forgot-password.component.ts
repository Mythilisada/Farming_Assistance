import { Component, OnInit } from '@angular/core';
import { FarmerServiceService } from '../farmer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  farmerServ:FarmerServiceService;
  router:Router;
  constructor(farmerServ:FarmerServiceService,router:Router) {
    this.farmerServ=farmerServ;
    this.router=router;
   }

  ngOnInit() {
  }

  forgotPassword(data:any){
  this.farmerServ.forgotPassword(data);
  }

 

}
