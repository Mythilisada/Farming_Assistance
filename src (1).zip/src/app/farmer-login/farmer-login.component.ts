import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FarmerServiceService } from '../farmer-service.service';

@Component({
  selector: 'app-farmer-login',
  templateUrl: './farmer-login.component.html',
  styleUrls: ['./farmer-login.component.css']
})
export class FarmerLoginComponent implements OnInit {

  router:Router;
  farmerService :FarmerServiceService;

  constructor(router:Router,farmerService:FarmerServiceService) {
    this.router=router;
    this.farmerService=farmerService;
   }

  ngOnInit() {
  }

  checkLogin(data:any){ 
   

  this.farmerService.getValidation(data.email, data.password).subscribe((res) =>{ 

    if (res === null)
      alert("please enter valid login details");

    else{
    //this.router.navigate(["/farmerHome",this.email]);
    this.router.navigateByUrl("farmerHome", data.email);
    alert("Login Successfully " + data.email);
    }
    }
    )


  }

}
