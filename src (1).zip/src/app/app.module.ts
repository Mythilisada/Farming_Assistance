import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FarmerLoginComponent } from './farmer-login/farmer-login.component';
import { FarmerRegisterComponent } from './farmer-register/farmer-register.component';
import { FarmerServiceService } from './farmer-service.service';
import { RouterModule } from '@angular/router';
import { ViewProductRequirementComponent } from './view-product-requirement/view-product-requirement.component';
import { FarmeHomeComponent } from './farme-home/farme-home.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { ViewFarmingTipsComponent } from './view-farming-tips/view-farming-tips.component';
import { ComplaintStatusComponent } from './complaint-status/complaint-status.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { SupplierRegisterComponent } from './supplier-register/supplier-register.component';
import { SupplierLoginComponent } from './supplier-login/supplier-login.component';
import { PostAddComponent } from './post-add/post-add.component';
import { SupplierHomeComponent } from './supplier-home/supplier-home.component';
import { HomePageComponent } from './home-page/home-page.component';

@NgModule({
  declarations: [
    AppComponent,
    FarmerLoginComponent,
    FarmerRegisterComponent,
    ViewProductRequirementComponent,
    FarmeHomeComponent,
    ViewUsersComponent,
    ViewFarmingTipsComponent,
    ComplaintStatusComponent,
    ForgotPasswordComponent,
    SupplierRegisterComponent,
    SupplierLoginComponent,
    PostAddComponent,
    SupplierHomeComponent,
    HomePageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule


  ],
  providers: [HttpClient, FarmerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
