import { Component, OnInit } from '@angular/core';
import { Supplier } from 'src/Beans/Supplier';
import { FarmerServiceService } from '../farmer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-supplier-register',
  templateUrl: './supplier-register.component.html',
  styleUrls: ['./supplier-register.component.css']
})
export class SupplierRegisterComponent implements OnInit {

  suppliesr:Supplier[];
  farmerServ:FarmerServiceService;
  router:Router
  constructor(farmerServ:FarmerServiceService,router:Router) { 
    this.farmerServ=farmerServ;
    this.router=router;
  }

  ngOnInit() {
  }

  onReg(data:any){
    let suppliers=new Supplier(data.supplier_Id,data.supplier_Name,data.supplier_Address,data.supplier_MobileNumber,data.supplier_Email,data.supplier_Password);
    this.farmerServ.addSupplier(suppliers).then(response=>{
      this.router.navigateByUrl('supplierLogin');
      },
      err=>{
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
          }
      });
     }
   
  

}
