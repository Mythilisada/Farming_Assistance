import { Component, OnInit } from '@angular/core';
import { Advertisement } from 'src/Beans/Advertisement';
import { FarmerServiceService } from '../farmer-service.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-post-add',
  templateUrl: './post-add.component.html',
  styleUrls: ['./post-add.component.css']
})
export class PostAddComponent implements OnInit {
  crop_Name:string;
  crop_Qty:string;
  reactiveForm: FormGroup;
  public userfile:any=File;
postAdd:Advertisement =new Advertisement(0,"","",0,"","");
  farmerServ:FarmerServiceService;
  router:Router;
  message:string;
  filestatus:Response;
  // httpClient:HttpClient;
 // selectedFile:File;
  constructor(farmerServ:FarmerServiceService,router:Router) {
    this.farmerServ=farmerServ;
    this.router=router;
    //this.httpClient=httpClient;
   }


  ngOnInit() {
    this.reactiveForm = new FormGroup({
    crop_Name: new FormControl(),
    crop_Qty: new FormControl()
    });
  }

  onSelectFile(event)
  {
const file=event.target.files[0];
console.log(file);
this.userfile=file;
  }

  saveForm(submitForm:FormGroup){
    const advtment=submitForm.value;
    const formData=new FormData();
    formData.append('advtment',JSON.stringify(advtment));
    formData.append('file',this.userfile);
    this.farmerServ.addPost(formData).subscribe((data)=>{
  //this.service.saveEmployeeProfile(formData).subscribe((data)=>{
    this.filestatus=data;
        if(this.filestatus.message === 'Document not uploaded' ){
         console.log("if");
        this.message='Document not uploaded';
        }
        else{
          alert("Uploaded succesfully");
          
          //
          this.router.navigate(['supplierHome'])
        }
        
      },
      error=>{
        this.message="*all fields are required";
      }
    );
    }
  }




