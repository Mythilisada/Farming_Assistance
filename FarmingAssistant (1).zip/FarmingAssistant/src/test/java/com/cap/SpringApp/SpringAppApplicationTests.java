package com.cap.SpringApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
