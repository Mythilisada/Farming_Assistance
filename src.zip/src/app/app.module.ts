import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FarmerLoginComponent } from './farmer-login/farmer-login.component';
import { FarmerRegisterComponent } from './farmer-register/farmer-register.component';
import { FarmerServiceService } from './farmer-service.service';
import { RouterModule } from '@angular/router';
import { ViewProductRequirementComponent } from './view-product-requirement/view-product-requirement.component';
import { FarmeHomeComponent } from './farme-home/farme-home.component';
import { ViewUsersComponent } from './view-users/view-users.component';

@NgModule({
  declarations: [
    AppComponent,
    FarmerLoginComponent,
    FarmerRegisterComponent,
    ViewProductRequirementComponent,
    FarmeHomeComponent,
    ViewUsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [HttpClient, FarmerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
